module core.app {
  exports core.util;
}