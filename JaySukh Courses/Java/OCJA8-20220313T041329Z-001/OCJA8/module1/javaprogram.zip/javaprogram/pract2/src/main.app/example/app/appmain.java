package example.app;

import core.util.workutil;

public class appmain {
    public static void main(String[] args) {
        workutil.doSomething();
    }
}