package core.util;

public class workutil {
  public static void doSomething() {
      System.out.println("WorkUtil working..");
  }
}