package pack14;
import java.util.*;
import pack13.*;
class testarmstrong extends armstrong
{
		public static void main(String arg[])
		{
				testarmstrong t1=new testarmstrong();
				t1.getvalues();
				t1.checkarmstrong();
		}
}