package pack4;
import pack3.*;
class testaccount
{
		public static void main(String arg[])
		{
			account a1=new account();
			a1.getvalues();
			a1.showvalues();
		}
}
