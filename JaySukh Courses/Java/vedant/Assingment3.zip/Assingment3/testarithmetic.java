package pack12;
import pack11.*;
class testarithmetic extends arithmetic
{

		public static void main(String arg[])
		{
			testarithmetic t1=new testarithmetic();

			t1.getvalues();
			t1.printtable();
		}
}
