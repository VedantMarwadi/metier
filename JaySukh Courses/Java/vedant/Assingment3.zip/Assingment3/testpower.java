package pack8;
import pack7.*;
class testpower
{
		public static void main(String arg[])
		{
			power1 p1=new power1();
			p1.getvalues();
			p1.calpower();
		}
}
