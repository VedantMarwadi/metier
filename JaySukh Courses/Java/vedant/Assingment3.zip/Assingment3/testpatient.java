package pack6;
import pack5.*;
class testpatient
{
		public static void main(String arg[])
		{
			patient p1=new patient();
			p1.getvalues();
			p1.showvalues();
		}
}
