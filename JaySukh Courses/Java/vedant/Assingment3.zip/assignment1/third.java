import java.util.*;
class third
{
	public static void main(String arg[])
	{

		Scanner s=new Scanner(System.in);
		System.out.println("Enter single character");
		char ch=s.next().charAt(0);
		int a=ch;
		System.out.println("Ascii value of "+ch+" is "+a);

	}
}