import java.util.*;
class first
{
	public static void main(String arg[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter any string");
		String str=s.nextLine();
		System.out.println("Entered String is "+str);

	}
}